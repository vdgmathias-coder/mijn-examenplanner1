# Mijn Examenplanner

Een lokale-first Progressive Web App (PWA) in het Nederlands. De gegevens worden op het toestel opgeslagen via `localStorage`. Er is geen account of serverdatabase nodig.

## Smartschool-screenshots importeren
1. Open het tabblad **Smartschool** in de app.
2. Kies een screenshot van je Smartschool-planner.
3. Laat de tekst herkennen en controleer of verbeter de herkende tekst.
4. Kies het juiste vak en voeg de regels toe als taken.

De tekstherkenning gebeurt in je browser met Tesseract.js. De screenshot wordt niet naar een server of naar GitHub geüpload. De eerste keer is internet nodig om de tekstherkenner en de Nederlandse taalgegevens te laden. OCR kan fouten maken. Deze versie importeert regels als taken; ze herkent nog niet automatisch deadlines of examendata. Verwijder privégegevens uit de herkende tekst voordat je importeert.

## Bestanden
- `index.html`, `style.css`, `app.js`: de app
- `manifest.json`: PWA-instellingen en app-naam
- `sw.js`: offline cache/service worker
- `icons/`: app-iconen

## Update plaatsen in je bestaande GitHub-project
1. Maak voor de zekerheid eerst een reservekopie via de knop in de app.
2. Open je bestaande repository op GitHub.
3. Kies **Add file → Upload files**.
4. Pak deze ZIP uit op je computer. Upload de inhoud van de map (niet de map zelf) naar de hoofdmap van de repository.
5. Bevestig dat bestaande bestanden met dezelfde namen vervangen mogen worden en klik **Commit changes**.
6. Wacht tot GitHub Pages klaar is. Open daarna je bestaande app opnieuw.

De app gebruikt dezelfde lokale opslag-sleutel als de oorspronkelijke versie. De bestaande gegevens op hetzelfde toestel blijven normaal behouden zolang je de websitegegevens niet wist. Maak toch eerst een reservekopie.

## Gratis online zetten met HTTPS (GitHub Pages)
1. Maak gratis een account op https://github.com als je er nog geen hebt.
2. Maak een nieuwe repository, bijvoorbeeld `mijn-examenplanner`.
3. Upload alle bestanden en de map `icons` uit deze zip naar de hoofdmap van de repository.
4. Open in GitHub de repository: **Settings → Pages**.
5. Kies bij **Build and deployment** voor **Deploy from a branch**.
6. Kies branch **main** en map **/(root)**, en klik **Save**.
7. Wacht tot GitHub Pages het adres toont, meestal `https://JOUW-GEBRUIKERSNAAM.github.io/mijn-examenplanner/`.
8. Open dat HTTPS-adres in Safari. De eerste keer is internet nodig om de app en offline bestanden te laden.

GitHub Pages is voor een eenvoudige statische PWA doorgaans gratis. Publiceer geen persoonlijke of gevoelige informatie in de repository; alleen de appbestanden horen daar.

## Installeren op iPhone
1. Open het GitHub Pages-adres in **Safari** (niet in een ingebouwde browser van een andere app).
2. Tik op de knop **Delen** (vierkant met pijl omhoog).
3. Scrol en kies **Zet op beginscherm** / **Add to Home Screen**.
4. Controleer de naam **Mijn Examenplanner** en tik op **Voeg toe**.
5. Start de app via het nieuwe beginscherm-icoon.

## Gegevens en reservekopieën
- Examens, lessen, leerstof, planning en sessies worden lokaal in Safari/app-opslag bewaard.
- Wis de websitegegevens van Safari niet als je de gegevens wilt behouden.
- Gebruik de downloadknop rechtsboven om een JSON-reservekopie te bewaren.
- Gebruik dezelfde knop en kies daarna een JSON-bestand om een reservekopie terug te zetten.
- Een reservekopie kan je ook bewaren in Bestanden/iCloud Drive.

## Belangrijke uitleg over de automatische planner
De planner gebruikt je ingestelde start- en einduur, weekrooster, examens en open leerstof. Hij plant blokken vanaf morgen (tot maximaal 45 dagen), met het eerstvolgende examen als prioriteit, en laat een kleine buffer tussen blokken. De gegenereerde blokken zijn voorstellen: controleer ze en pas ze zelf aan. Stel de studie-uren zo in dat ze overeenkomen met je echte vrije tijd. De app kent geen uitzonderlijke afspraken, huiswerkdeadlines of reistijd tenzij je die zelf verwerkt.

## Technische beperking
Dit is een volledig client-side app zonder synchronisatie tussen toestellen. Bij verlies of reset van het toestel kan lokale data verloren gaan; maak daarom geregeld een reservekopie. Een PWA kan offline werken nadat ze minstens één keer online is geopend en de service worker de bestanden heeft gecachet.
