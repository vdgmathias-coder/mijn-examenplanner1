# Mijn Examenplanner

Een lokale-first Progressive Web App (PWA) in het Nederlands. De gegevens worden op het toestel opgeslagen via `localStorage`. Er is geen account of serverdatabase nodig.

## Bestanden
- `index.html`, `style.css`, `app.js`: de app
- `manifest.json`: PWA-instellingen en app-naam
- `sw.js`: offline cache/service worker
- `icons/`: app-iconen

## Gratis online zetten met HTTPS (GitHub Pages)
1. Maak gratis een account op https://github.com als je er nog geen hebt.
2. Maak een nieuwe repository, bijvoorbeeld `mijn-examenplanner`.
3. Upload alle bestanden en de map `icons` uit deze zip naar de hoofdmap van de repository.
4. Open in GitHub de repository: **Settings → Pages**.
5. Kies bij **Build and deployment** voor **Deploy from a branch**.
6. Kies branch **main** en map **/(root)**, en klik **Save**.
7. Wacht tot GitHub Pages het adres toont, meestal `https://JOUW-GEBRUIKERSNAAM.github.io/mijn-examenplanner/`.
8. Open dat HTTPS-adres in Safari. De eerste keer is internet nodig om de app en offline bestanden te laden.

GitHub Pages is voor een eenvoudige statische PWA doorgaans gratis. Publiceer geen persoonlijke of gevoelige informatie in de repository; alleen de appbestanden horen daar.

## Installeren op iPhone
1. Open het GitHub Pages-adres in **Safari** (niet in een ingebouwde browser van een andere app).
2. Tik op de knop **Delen** (vierkant met pijl omhoog).
3. Scrol en kies **Zet op beginscherm** / **Add to Home Screen**.
4. Controleer de naam **Mijn Examenplanner** en tik op **Voeg toe**.
5. Start de app via het nieuwe beginscherm-icoon.

## Gegevens en reservekopieën
- Examens, lessen, leerstof, planning en sessies worden lokaal in Safari/app-opslag bewaard.
- Wis de websitegegevens van Safari niet als je de gegevens wilt behouden.
- Gebruik de downloadknop rechtsboven om een JSON-reservekopie te bewaren.
- Gebruik dezelfde knop en kies daarna een JSON-bestand om een reservekopie terug te zetten.
- Een reservekopie kan je ook bewaren in Bestanden/iCloud Drive.

## Belangrijke uitleg over de automatische planner
De planner gebruikt je ingestelde start- en einduur, weekrooster, examens en open leerstof. Hij plant blokken vanaf morgen (tot maximaal 45 dagen), met het eerstvolgende examen als prioriteit, en laat een kleine buffer tussen blokken. De gegenereerde blokken zijn voorstellen: controleer ze en pas ze zelf aan. Stel de studie-uren zo in dat ze overeenkomen met je echte vrije tijd. De app kent geen uitzonderlijke afspraken, huiswerkdeadlines of reistijd tenzij je die zelf verwerkt.

## Technische beperking
Dit is een volledig client-side app zonder synchronisatie tussen toestellen. Bij verlies of reset van het toestel kan lokale data verloren gaan; maak daarom geregeld een reservekopie. Een PWA kan offline werken nadat ze minstens één keer online is geopend en de service worker de bestanden heeft gecachet.
